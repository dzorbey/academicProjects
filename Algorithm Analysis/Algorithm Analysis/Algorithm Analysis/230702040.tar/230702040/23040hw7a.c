//ZORBEY GOKYILDIZ 230702040


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int number_of_trucks=1;
int find(int capacity_of_trucks,int number_of_items,int hold[number_of_items],FILE *file);




int find(int capacity_of_trucks,int number_of_items,int hold[number_of_items],FILE *file)
{

int tmp=capacity_of_trucks;
int x=number_of_items;
int i=0;int k=0; int m=0;
int sum=0;
int tmp2;
int tut;
int flag=0;
tut=0;
int mysum=0;


while(x!=0)
{
	hold[i];       //keep the largest available
	


	if(flag==1)
	{
	 tut=i;
	 flag=0;
	}

	
	if(hold[i] > capacity_of_trucks)
	{
      
	}
	else 
	{	
        capacity_of_trucks = capacity_of_trucks - hold[i]; i++;
	}


	
	if((capacity_of_trucks < hold[i] || capacity_of_trucks==0))
	{
		flag=1;
		//tmp2=k;
	    capacity_of_trucks=tmp; //subinstance is solved.
        
   	    printf("TRUCK %d\n", number_of_trucks);
		fprintf(file, "TRUCK %d\n", number_of_trucks);
		
		printf("\nID       WEIGHT");
		fprintf(file, "\nID       WEIGHT");
		number_of_trucks++;


        for(m=tut; m<i; m++)
		{ 
			mysum=mysum+hold[m];
		    printf("\n%d       %d\n", m,hold[m]);
			fprintf(file, "\n%d       %d\n", m,hold[m]);
		}
        
        printf("\nTOTAL    %d\n", mysum);
        fprintf(file,"\nTOTAL    %d\n", mysum);
		printf("\n-----------\n\n\n");
	    fprintf(file,"\n-----------\n\n\n");
	}
     mysum=0;


 x--;
// k++;

}
printf("\n%d number of trucks are needed for that project", number_of_trucks-1);
fprintf(file,"\n%d number of trucks are needed for that project", number_of_trucks-1);
return 0;
}




int main()
{
	FILE *file;
	FILE *file2;

	char tmp[30];
	int i=0;
	int capacity_of_trucks;
	int number_of_items;

    clock_t start,finish;
	double duration;
    time_t seconds;
	time(&seconds);

    printf("Enter the name of the file to be proceed\n");
	scanf("%s", tmp);

    if((file=fopen(tmp,"r")) == NULL)
	{printf("FILE NOT OPENED");}

	
	file2=fopen("output.txt" ,"w");
	
	fscanf(file, "%d", &capacity_of_trucks);
	fscanf(file, "%d", &number_of_items);


    int hold[number_of_items];
	
	while(!feof(file))
	{
		fscanf(file, "%d", &hold[i]);
		i++;
	}

    start=clock();
    find(capacity_of_trucks,number_of_items,hold,file2);
	finish=clock();
    duration=(double)(finish - start) / (CLOCKS_PER_SEC);

    printf("\nExecution time: %10.5f seconds\n\n", duration);
    fprintf(file2,"\nExecution time: %10.5f seconds\n\n", duration);

	printf("\nOutput is also written in the file named as output.txt\n");
	fclose(file);
	return 0;
}