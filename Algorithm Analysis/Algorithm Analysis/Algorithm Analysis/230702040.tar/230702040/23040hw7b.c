//ZORBEY GOKYILDIZ 230702040

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int number_of_trucks=1;
int find2(int capacity_of_trucks,int number_of_items,int hold[number_of_items],FILE *file);




int find2(int capacity_of_trucks,int number_of_items,int hold[number_of_items],FILE  *file)
{


int tmp=capacity_of_trucks;
int x=number_of_items;
int i=0; int m=0;
int sum=0;
int tut=0;
int flag=0;
int sakla; int sakla2; int l; int mysum=0;



while(x!=0)
{
	hold[i];       //keep the largest available
	


	if(flag==1)
	{
	 tut=i;
	 flag=0;                         //if the next coint doesnt acceed the limit take it else reject.
	}

	
	if(hold[i] > capacity_of_trucks)
	{
      
	}
	else 
	{	
		sum=sum+hold[i];
        capacity_of_trucks = capacity_of_trucks - hold[i]; i++;
	}


	
	if((capacity_of_trucks < hold[i] || capacity_of_trucks==0))
	{ 
		flag=1;                                                 //subinsctance is solved.
	    number_of_trucks++;

        printf("TRUCK %d\n", number_of_trucks);
		fprintf(file, "TRUCK %d\n", number_of_trucks);
		printf("\nID       WEIGHT");
		fprintf(file, "\nID       WEIGHT");


         
		 for(l=i; l<number_of_items; l++)              //HERE i search for a value to the down of the file
		 {                                             //which will not exceed the current capacity.
			 if( (hold[l] < capacity_of_trucks) || hold[l]+sum <=tmp)
			 {
              sakla2=hold[i];
              hold[i]=hold[l];
              sakla=l;
			  hold[l]=sakla2;

              while(sakla!=number_of_items)
              {
				 if(l+1<=number_of_items){
					 hold[l]=hold[l+1];}
                  
				  sakla++;
              }
			  break;
            }
		 }
		 
		    for(m=tut; m<i; m++)
			{
			  mysum=mysum+hold[m];
		      printf("\n%d       %d\n", m,hold[m]);
			  fprintf(file, "\n%d       %d\n", m,hold[m]);
			}
	
		 
		 sum=0;
		 capacity_of_trucks=tmp;



         printf("\nTOTAL    %d\n", mysum);
         fprintf(file,"\nTOTAL    %d\n", mysum);
		 printf("\n-----------\n\n\n");
	     fprintf(file,"\n-----------\n\n\n");
	}
    mysum=0;
	x--;
}
printf("\n%d number of trucks are needed for that project", number_of_trucks-1);
fprintf(file,"\n%d number of trucks are needed for that project", number_of_trucks-1);
return 0;

}






int main()
{
	FILE *file;
	FILE *file2;

	char tmp[30];
	int i=0;
	int capacity_of_trucks;
	int number_of_items;

    clock_t start,finish;
	double duration;
    time_t seconds;
	time(&seconds);


    printf("Enter the name of the file to be proceed.\n");
	scanf("%s", tmp);

    if((file=fopen(tmp,"r")) == NULL)
	{printf("FILE NOT OPENED");}

    file2=fopen("output2.txt" ,"w");

	
	
	fscanf(file, "%d", &capacity_of_trucks);
	fscanf(file, "%d", &number_of_items);


    int hold[number_of_items];
	
	while(!feof(file))
	{
		fscanf(file, "%d", &hold[i]);
		i++;
	}

    start=clock();
    find2(capacity_of_trucks,number_of_items,hold,file2);
	finish=clock();
    duration=(double)(finish - start) / (CLOCKS_PER_SEC);


    printf("\nExecution time: %10.5f seconds\n\n", duration);
	fprintf(file2, "\nExecution time: %10.5f seconds\n\n", duration);
	
	printf("\nOutput is also written in the file named as output2.txt\n");
	fclose(file); fclose(file2);
	return 0;
}