#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int kenpachi(int n);
int dynamic_kenpachi(int n);




int kenpachi(int n)
{
	if(n==1 || n==2 || n==0)
	{
		return 1;
	}
	else
	{
		return (kenpachi(n-1) + kenpachi(n-3));
	}
}



int dynamic_kenpachi(int n)
{
	int tmp[2*n];
	int i;

	tmp[0]=1;
	tmp[1]=1;
	tmp[2]=1;

	for(i=3; i<=n; i++)
	{
		tmp[i]=tmp[i-1]+tmp[i-3];
	}

	return tmp[n];

}







int main()
{

    clock_t start,finish;
	double duration[2];
    time_t seconds;
	time(&seconds);


	int k;
	int result1,result2;
	printf("Enter the kenpachi number to calculate :");
	scanf("%d",&k);
    

        start=clock();
        result1=dynamic_kenpachi(k);
		//printf("%d\n",result1);
        finish=clock();
        duration[0]=(double)(finish - start) / (CLOCKS_PER_SEC/1000);


        start=clock();
        result2=kenpachi(k);
		//printf("%d", result2);
        finish=clock();
        duration[1]=(double)(finish - start) / (CLOCKS_PER_SEC/1000);


    printf("\n1) Dynamic programming\n");
	printf("%dth kenpachi number: %d\n", k, result1);
	printf("Execution time: %10.5f mseconds\n\n", duration[0]);
 
	printf("\n2) Divide and connquer\n");
    printf("%dth kenpachi number: %d\n", k, result2);
    printf("Execution time: %10.5f mseconds", duration[1]);
 

    return 0;
}











