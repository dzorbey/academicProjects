//ZORBEY GOKYILDIZ 230702040


#include <stdio.h>

//The structure that holds the data for the matrixes.
struct matrix {

	int row;
	int col;
	char name;
};
typedef struct matrix Matrix;


int calculate(int from,int to,int hold, int i, int M[i][i],int a[30],Matrix *const matrix);
void writeintofile(int old1, int old2, int old3,Matrix *const matrix,int hold);




//The function that writes the given input into the file.
void writeintofile(int old1, int old2, int old3,Matrix *const matrix,int hold){


FILE *file;


    if((file=fopen("output.txt","w")) == NULL)
	{printf("FILE2 NOT OPENED");}




fprintf(file, "( %c...%c ) x ( %c x %c )\n", matrix[old1-1].name, matrix[old3-1].name,matrix[old3+1-1].name, matrix[old2-1].name);
fseek(file, 8*sizeof(int), SEEK_SET);
fprintf(file,  "%d mutiplications.", hold);



  fclose(file);



}



//This is the function that calculates the least multiplication process.
//I repeat the main part of the function twice for higher accuracy because when the 
//values are calculated initialy there will be some false calculations of the multiplication processes.
//When the same process is repeated a better answer can be achieved.

int calculate(int from,int to,int hold,int i, int M[i][i],int a[30],Matrix *const matrix)
{
	int tmp1,tmp2,tmp3;
	int q=0;
    int tmp=from;
    int old,old1,old2,old3,myold=10000;

   for(from=1; from<=hold; from++)
   {
	   M[from][from]=0;
   }
    from=tmp;


//M[x][x+1] is calculated here.

  for(tmp=1; tmp<hold; tmp++)
  {
	  M[tmp][tmp+1]=a[tmp-1]*a[tmp]*a[tmp+1];
	  printf("M[%d][%d]  %d\n" ,tmp,tmp+1, M[tmp][tmp+1]);
  }



  



   for(tmp1=1; tmp1<=to-1; tmp1++)
   {
	   for(tmp2=tmp1+1; tmp2<=to; tmp2++)
	   {
		   
		   for(tmp3=1; tmp3<=tmp2-1; tmp3++)
		   {
		
			   q=M[tmp1][tmp3] + M[tmp3+1][tmp2] + (a[tmp1-1]*a[tmp3]*a[tmp2]);
			   //printf("\n%d  M[%d][%d] + M[%d][%d] +(a[%d-1]*a[%d]*a[%d])", q,  tmp1,tmp3,tmp3+1,tmp2,tmp1,tmp3,tmp2);
			        


			   if(q< M[tmp1][tmp2])
			   {
				   M[tmp1][tmp2]=q;
			   }
		   }  
	   }
   }

   printf("\n\n\n");


for(tmp1=1; tmp1<=to-1; tmp1++)
   {
	   for(tmp2=tmp1+1; tmp2<=to; tmp2++)
	   {
		   
		   for(tmp3=1; tmp3<=tmp2-1; tmp3++)
		   {
		
			   q=M[tmp1][tmp3] + M[tmp3+1][tmp2] + (a[tmp1-1]*a[tmp3]*a[tmp2]);
			   printf("\n%d  M[%d][%d] + M[%d][%d] +(a[%d-1]*a[%d]*a[%d])", q,  tmp1,tmp3,tmp3+1,tmp2,tmp1,tmp3,tmp2);
			
		
			   if(q< M[tmp1][tmp2])
			   {
				   
				   M[tmp1][tmp2]=q;
			   }

			   if(tmp1==from && tmp2==to) //When we find the desired place M[from][to], we keep the 
			   {                         // values of the related calculations. 
				    if(q<myold)
					{
						myold=q;
						old1=tmp1; 
						old2=tmp2;
						old3=tmp3;
					}
			   }
		   }  
	   }
   }
       printf("\n\n\n\n\nThe represantation of the least multiplication for the given value: %d\n\n", M[from][to]);
	   printf("M[%d][%d]=M[%d][%d] + M[%d][%d] +(a[%d-1]*a[%d]*a[%d])", from,to,  old1,old3,old3+1,old2,old1,old3,old2);

	   writeintofile(old1,old2,old3,matrix,M[from][to]);
 
   
   return 0;

}




int main()
{
   int k=1;
   int i=0;
   int q=2;
   int a[30];
   int m=0;
   int z;
   int o;
   Matrix mymatrix[26];
    
   const char L[26]={'A','B','C','D','E','F','G','H','I','J','K',
	                 'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};   

   int number; 

	FILE *file;

    if((file=fopen("input.txt","r")) == NULL)
	{printf("FILE2 NOT OPENED");}



	fscanf(file, "%d", &number);


	while(!feof(file))
	{
		fscanf(file, "%d %d" , &mymatrix[i].row, &mymatrix[i].col);
        printf(" %d %d\n", mymatrix[i].row, mymatrix[i].col);
		
		i++;
		
	}i=0;
    
	int M[number][number];


	//Since we  dont use the half of the double array(matrix), for the places like M[y][x]...
	// where y>x the high valued places of that matrix is not going to be updated in the process.
	// so we sort of guarantee not to make an calculations in the lower part of the matrix. Which will
	//result in false multiplications.
	
	for(z=0; z<=number; z++)
	{
		for(o=0; o<=number; o++)
		{
			M[z][o]=1000;
		}
	}

 
	   while(L[i]) { mymatrix[i].name=L[i]; i++; }



	    a[0]=mymatrix[0].row;	a[1]=mymatrix[0].col;


		q=2;
		for(k=1; k<number; k++) // colomns and rows of the matrixes are sent to an array.
		{
			a[q]=mymatrix[k].col;
			//printf("%d ", a[q]);
		    q++;
		}

        printf("\n");
        calculate(1,number,number,number,M,a,mymatrix);







	fclose(file);

	return 0;
}